package com.saeyan.javabeans;

public class MemberBean {

}
