
function test_id() {
		alert("사용 가능한 아이디입니다.");
	}
	
function test() {
		alert("회원가입 완료!");
	}
