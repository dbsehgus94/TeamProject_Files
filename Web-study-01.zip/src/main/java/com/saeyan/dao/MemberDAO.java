package com.saeyan.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.saeyan.dto.MemberVO;

public class MemberDAO {
	private MemberDAO() {
		
	}
	
	private static MemberDAO instance = new MemberDAO();
	
	public static MemberDAO getInstance() {
		return instance;
	}
	// ������ ���̵� ������ 1, ������ -1�� ��ȯ�Ѵ�.
		public int confirmID(String userid) {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			int result = -1;

			String sql = "select pwd from membership where userid=?";

			try {
				conn = getConnection(); // DB ���� �õ�
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, userid);

				rs = pstmt.executeQuery();

				if (rs.next()) { // ��ȸ ����� ������ userid�� �����Ѵٴ� �ǹ�
					result = 1;
				} else {
					// ��ȸ�� ����� ���� �����Ƿ� userid�� �������� ����.
					result = -1;
				}

			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (conn != null) {
						conn.close();
					}
					if (pstmt != null) {
						pstmt.close();
					}
					if (rs != null) {
						rs.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			return result;
		}
	    
	    public int insertMember(MemberVO mVo) {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;

			int result = 0;

			String sql = "insert into membership values(?, ?, ?, ?, ?, ?)";

			try {
				conn = getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, mVo.getName());
				pstmt.setString(2, mVo.getUserid());
				pstmt.setString(3, mVo.getPwd());
				pstmt.setString(4, mVo.getEmail());
				pstmt.setString(5, mVo.getPhone());
				pstmt.setInt(6, mVo.getAdmin());

				result = pstmt.executeUpdate(); // �����ϸ� insert�� ������ ���� ���� ��ȯ, �����ϸ� 0
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (conn != null) {
						conn.close();
					}
					if (pstmt != null) {
						pstmt.close();
					}
					if (rs != null) {
						rs.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			return result;
		}
	
	public Connection getConnection() throws Exception {
		Connection conn = null;
		Context initContext = new InitialContext();
		Context envContext = (Context) initContext.lookup("java:/comp/env");
		DataSource ds = (DataSource) envContext.lookup("jdbc/myoracle");
		conn = ds.getConnection();
		return conn;
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String name = request.getParameter("name");
		String userid = request.getParameter("userid");
		String pwd = request.getParameter("pwd");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		int admin = Integer.parseInt(request.getParameter("admin"));
		int result = 0;
		
		MemberDAO mDao = MemberDAO.getInstance();
		
		MemberVO mVo = new MemberVO();
		mVo.setName(name);
		mVo.setUserid(userid);
		mVo.setPwd(pwd);
		mVo.setEmail(email);
		mVo.setPhone(phone);
		mVo.setAdmin(admin);
		
		result = mDao.insertMember(mVo);
		if(result == 1) {
			HttpSession session = request.getSession();
			session.setAttribute("userid", userid);
			request.setAttribute("message", "ȸ�� ���� ����");
		}else {
			request.setAttribute("message", "ȸ�� ���� ����");
		}
		request.getRequestDispatcher("member/login.jsp").forward(request, response);
		
	}
}
